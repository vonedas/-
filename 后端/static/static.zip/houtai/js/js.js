

    // 动态展开二级菜单
    $('.menu > li').click(function(){
        $(this).find('.sub-menu').slideToggle();
        $(this).siblings().find('.sub-menu').slideUp();
    });

    // 搜索按钮点击事件
    $('.search button').click(function(){
        var keyword = $('.search input').val();
        // 根据关键字进行搜索
    });

